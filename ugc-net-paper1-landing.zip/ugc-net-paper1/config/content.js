// Page copy that changes more often than the code: units, free questions and FAQs.
const site = require('./site');

const inc = site.product.includes;
const minMonths = Math.min(...site.plans.map((p) => p.months));
const maxMonths = Math.max(...site.plans.map((p) => p.months));

// The 10 units of UGC NET Paper 1, as named in the official syllabus.
const units = [
  ['Teaching Aptitude', 'Levels of teaching, learner characteristics, teaching methods and evaluation systems.'],
  ['Research Aptitude', 'Types and methods of research, steps of research, thesis writing and research ethics.'],
  ['Comprehension', 'A passage followed by questions that test careful reading.'],
  ['Communication', 'Types and characteristics of communication, barriers and classroom communication.'],
  ['Mathematical Reasoning and Aptitude', 'Series, codes, relationships, percentages, averages, interest, and time and distance.'],
  ['Logical Reasoning', 'Arguments, deductive and inductive reasoning, analogies, Venn diagrams and Indian logic.'],
  ['Data Interpretation', 'Reading tables and graphs, quantitative and qualitative data, data and governance.'],
  ['Information and Communication Technology (ICT)', 'ICT terms, internet and e-mail, digital initiatives in higher education.'],
  ['People, Development and Environment', 'SDGs, pollution, climate change, natural hazards, energy and international agreements.'],
  ['Higher Education System', 'Learning in ancient India, growth after Independence, policies, governance and value education.'],
];

// [tone, icon, title, text]
const features = [
  ['flame', 'timer', `${inc.fullMocks} full-length mocks`, '50 questions, an exam timer and a score out of 100, in the NTA computer-based test style.'],
  ['peacock', 'grid', `${inc.unitTests} unit-wise tests`, 'Practise each of the 10 units on its own and fix your weakest units first.'],
  ['haldi', 'archive', `${inc.pyqPapers} previous year papers`, 'Past UGC NET Paper 1 questions as timed tests, so you learn what NTA actually asks.'],
  ['leaf', 'lang', 'Hindi and English', 'Every test is available in both languages. Read each question in the one you think in.'],
  ['ember', 'check', 'A solution for every question', 'Step-by-step explanations, not just the answer key, so a wrong answer still teaches you something.'],
  ['peacock', 'chart', 'AI gap analysis', 'After each test, see which units cost you marks and get a practice set built around them.'],
].filter((f) => site.product.bilingual || f[1] !== 'lang');

// Five original sample questions for the free mini test.
const quiz = [
  {
    unit: 'Research Aptitude',
    q: 'A hypothesis which states that there is no relationship between the variables being studied is called a:',
    options: ['Directional hypothesis', 'Null hypothesis', 'Alternative hypothesis', 'Research hypothesis'],
    answer: 1,
    why: 'The null hypothesis (H₀) states that there is no relationship or difference. A study collects evidence to reject it or fail to reject it.',
  },
  {
    unit: 'Mathematical Reasoning',
    q: 'If A : B = 3 : 5 and B : C = 2 : 3, then A : C is:',
    options: ['1 : 2', '3 : 5', '2 : 5', '6 : 10'],
    answer: 2,
    why: 'Make B the same in both ratios: A : B = 6 : 10 and B : C = 10 : 15. So A : C = 6 : 15 = 2 : 5.',
  },
  {
    unit: 'Logical Reasoning',
    q: 'Statements: All teachers are graduates. Some graduates are researchers. Conclusion: Some teachers are researchers. The conclusion:',
    options: ['Definitely follows', 'Does not necessarily follow', 'Is definitely false', 'Follows, because all teachers are graduates'],
    answer: 1,
    why: 'The graduates who are researchers may not include any teachers. "Graduates" links the two statements without guaranteeing an overlap, so the conclusion does not necessarily follow.',
  },
  {
    unit: 'ICT',
    q: 'Which of the following is an input device?',
    options: ['Monitor', 'Printer', 'Speaker', 'Scanner'],
    answer: 3,
    why: 'A scanner sends data into the computer. Monitors, printers and speakers are output devices.',
  },
  {
    unit: 'Higher Education System',
    q: 'The National Education Policy 2020 aims to raise the Gross Enrolment Ratio in higher education to what level by 2035?',
    options: ['35%', '40%', '50%', '60%'],
    answer: 2,
    why: 'NEP 2020 sets a target of 50% GER in higher education, including vocational education, by 2035.',
  },
];

const faqs = [
  ['Is this an official NTA or UGC test series?',
    `No. ${site.brand.name} is an independent exam-preparation platform by ${site.brand.legalName}, not affiliated with NTA or UGC. Our tests follow the Paper 1 pattern published by NTA. For official notices, dates and results, always check <a href="${site.exam.officialSite}" target="_blank" rel="noopener">${site.exam.officialSiteLabel}</a>.`],
  ['How do I start after paying?',
    `<ol>${site.product.accessSteps.map((s) => `<li>${s}</li>`).join('')}</ol>Your payment receipt, with these steps, opens as soon as the payment is confirmed.`],
  ['Which payment methods can I use?',
    'UPI (Google Pay, PhonePe, Paytm and any other UPI app), debit and credit cards, net banking and wallets. Payments are processed securely by Razorpay. We never see your card details or UPI PIN.'],
  ['Are the tests available in Hindi?',
    site.product.bilingual ? 'Yes. Every test is available in Hindi and English.' : 'Tests are currently in English.'],
  ['Does this include Paper 2?',
    'No. This test series is for Paper 1 only, which is common to every UGC NET subject.'],
  ['How long can I use it?',
    `From the date of payment: ${site.plans.map((p) => `${p.months} months on the ${p.name} plan`).join(', ')}. The plans are one-time payments and do not renew automatically.`],
  ['Money was deducted but I did not get access. What now?',
    `Most payments are confirmed within a minute. If yours isn't, email <a href="mailto:${site.brand.supportEmail}">${site.brand.supportEmail}</a> with your payment ID (it starts with <code>pay_</code>). If a payment fails after money is deducted, your bank reverses it automatically, usually within 5 to 7 working days.`],
  ['Can I get a refund?',
    'Yes, if you ask within 48 hours of paying and have not attempted a full-length mock, and in a few other cases such as a duplicate charge. See our <a href="/refund-policy">Cancellation and Refund Policy</a>.'],
];

module.exports = { units, features, quiz, faqs, minMonths, maxMonths };
