// ---------------------------------------------------------------------------
// Everything a non-developer may need to change lives in this one file.
// Prices shown on the page and prices charged by Razorpay both come from here,
// so the two can never disagree.
// ---------------------------------------------------------------------------

module.exports = {
  brand: {
    name: 'Agni Shiksha',
    nameHindi: 'अग्नि शिक्षा',
    tagline: 'Ignite your preparation.',
    legalName: 'Qureskill Private Limited',
    cin: 'U85500BR2024PTC069215',
    address: 'Prem Nagar, Ganga Bridge Colony, Sabour, Bhagalpur, Bihar 813210, India',
    supportEmail: 'support@agnishiksha.app',
    grievanceEmail: 'grievance@agnishiksha.app',
    phones: ['+91 73888 17775', '+91 72818 55855'],
    supportHours: 'Monday to Saturday, 10 am to 6 pm IST',
    website: 'https://www.agnishiksha.app',
    playStoreUrl: 'https://play.google.com/store/apps/details?id=com.agnishiksha.app',
    themeColor: '#EF6F1C',
    // Optional: GSTIN printed on payment receipts. Leave empty if not registered.
    gstin: '',
  },

  product: {
    name: 'UGC NET Paper 1 Test Series',
    shortName: 'Paper 1 Test Series',
    // IMPORTANT: set these to what is actually inside the test series in the app.
    // They are printed on the sales page, so they must be true.
    includes: {
      fullMocks: 20,      // full-length 50-question mocks
      unitTests: 50,      // unit-wise tests across the 10 units
      pyqPapers: 10,      // previous year papers as timed tests
    },
    bilingual: true,      // tests available in Hindi and English
    // How a buyer starts using the purchase (shown on the page and the receipt).
    accessSteps: [
      'Pay securely with UPI, card, net banking or wallet.',
      'Your test series is linked to the mobile number you pay with.',
      'Install Agni Shiksha from Google Play, sign in with that same number and start Mock 1.',
    ],
  },

  // Plans. `id` is what the browser sends; the server looks up the price here.
  // price is in rupees, inclusive of all taxes.
  plans: [
    {
      id: 'p1-3m',
      name: '3 months',
      price: 199,
      months: 3,
      blurb: 'Enough for one focused exam cycle.',
      badge: '',
    },
    {
      id: 'p1-12m',
      name: '12 months',
      price: 399,
      months: 12,
      blurb: 'Covers both the June and December cycles.',
      badge: 'Best value',
      featured: true,
    },
  ],

  currency: 'INR',

  // Exam facts shown in the "Paper 1 at a glance" section.
  // Source: NTA's UGC NET information bulletin (nta.ac.in). Re-check every cycle.
  exam: {
    officialSite: 'https://nta.ac.in',
    officialSiteLabel: 'nta.ac.in',
    patternCheckedOn: '30 October 2026',
    questions: 50,
    marks: 100,
    marksPerQuestion: 2,
    negativeMarking: false,
    sitting: 'one 3-hour sitting, with no break between them',
  },

  // Optional marketing tags. Leave empty to load nothing.
  analytics: {
    ga4Id: '',          // e.g. G-XXXXXXXXXX
    metaPixelId: '',    // e.g. 123456789012345
  },

  policiesUpdatedOn: '30 October 2026',
};
