# Agni Shiksha · UGC NET Paper 1 Test Series: sales page + Razorpay

A complete, deployable sales landing page for the UGC NET Paper 1 Test Series, with Razorpay payments,
server-side payment verification, a webhook safety net, payment receipts, an orders admin, and the
policy pages Razorpay checks before it activates your account.

Stack: Node.js 20+, Express 5, EJS templates, SQLite (better-sqlite3), the official `razorpay` SDK.
No frontend framework and no build step.

---

## 1. Run it on your computer (10 minutes)

```bash
npm install
cp .env.example .env        # then open .env and paste your Razorpay TEST keys
npm start                   # http://localhost:3000
```

Get test keys from **Razorpay Dashboard → switch to Test Mode → Account & Settings → API Keys**.
They start with `rzp_test_`. In test mode no real money moves. To pay, use:

| Method | Test details |
|---|---|
| Card | `4111 1111 1111 1111` (Visa) or `5267 3181 8797 5449` (Mastercard), any future expiry, any CVV |
| UPI | `success@razorpay` to succeed, `failure@razorpay` to fail (Razorpay recommends a small live payment to test UPI end to end) |
| Net banking / wallet | Pick any bank and choose Success or Failure on the mock page |

After paying you land on `/success?t=…`, the buyer's receipt. Open `/admin` (set `ADMIN_PASSWORD` first) to see the order.

Run the automated checks any time (they use a fake Razorpay, no keys needed):

```bash
npm test     # 21 checks: pricing, signatures, capture, webhook, duplicates, admin
```

---

## 2. What to change before launch

Everything you will want to edit is in **two files**. You don't need to touch the code.

**`config/site.js`**
- `product.includes`: **the number of mocks, unit tests and PYQ papers. Set these to what is really in the app.** They are printed on the page.
- `plans`: names, prices (in rupees, incl. GST) and months. The page and Razorpay both read from here, so they can never disagree.
- `brand`: company details, support email and phones, GSTIN (optional, printed on receipts).
- `analytics`: optional GA4 ID and Meta Pixel ID. The page then sends `begin_checkout` and `purchase` events.
- `exam`: Paper 1 pattern facts. Re-check against NTA's information bulletin each cycle.

**`config/content.js`**: the 10 units, the six feature cards, the five free questions and the FAQ.

Policy pages live in `views/policies/`. They are written for this product (one-time digital purchase,
48-hour refund window, delivery within 24 hours). Read them and adjust to your actual terms.

---

## 3. Going live with Razorpay: checklist

1. **Activate your Razorpay account** (KYC). When it asks for your website, give the domain where this runs.
   Razorpay checks these pages, which are all linked in the footer:
   `/terms`, `/privacy`, `/refund-policy`, `/shipping-policy`, `/contact`, `/about`, and pricing at `/#pricing`.
   For the "sample invoice" it asks for, make one test purchase and save the receipt page as PDF (Print → Save as PDF).
2. **Payment capture**: Dashboard → Account & Settings → Capture settings → **automatic**. (The code also captures
   any payment left "authorized", so nothing gets stuck either way.)
3. **Webhook**: Dashboard → Account & Settings → Webhooks → Add:
   - URL: `https://YOUR-DOMAIN/webhooks/razorpay`
   - Secret: any long random string; put the same value in `RAZORPAY_WEBHOOK_SECRET`
   - Events: `payment.authorized`, `payment.captured`, `payment.failed`, `order.paid`

   Webhooks are configured separately in Test and Live mode, so add it in both.
   The webhook is what confirms payments for buyers who close the tab before the page hears back.
4. **Switch to live keys** (`rzp_live_…`) in `.env`, set `BASE_URL=https://your-domain`, and restart.
   The server log says `Razorpay LIVE mode` when it starts.
5. **Set `ADMIN_PASSWORD`** (10+ characters). `/admin` stays switched off without it.
6. **Decide how buyers get access** (section 5).
7. **Google Play rule:** don't link to this page or mention web pricing **inside the Android app**. Google Play's
   Payments policy doesn't allow steering in-app users to outside payment. Share the page on Instagram, YouTube,
   WhatsApp, ads and your website instead. Add `?utm_source=instagram&utm_campaign=p1_launch` to links and the
   source shows up in `/admin` and the CSV.

---

## 4. How a payment flows

```
Browser                         This server                         Razorpay
───────                         ───────────                         ────────
Buy → form (name, phone, email)
  POST /api/orders  ─────────▶  price looked up from config
                                orders.create(amount, receipt) ───▶ order_XXXX
                     ◀────────  { keyId, orderId, amount }
Razorpay Checkout opens  ─────────────────────────────────────────▶ buyer pays (UPI/card/…)
handler(payment_id, order_id, signature)
  POST /api/payments/verify ─▶  HMAC-SHA256(order_id|payment_id, key_secret) == signature?
                                payments.fetch → same order? same amount?
                                authorized → capture; captured → mark PAID (once)
                                → grant access (your app backend, or /admin)
                     ◀────────  redirect /success?t=…   (receipt)

                                POST /webhooks/razorpay  ◀───────── order.paid / payment.captured
                                HMAC of raw body with webhook secret, de-duplicated by event id,
                                same "mark PAID once" path (covers closed tabs and slow UPI)
```

Security built in:
- The browser never decides the price. Sending `amount: 1` changes nothing (it's tested).
- Signatures are checked with constant-time comparison; the order ID used is the one stored on the server.
- Every payment is re-fetched from Razorpay and must match the order's ID, amount and currency.
- Checkout and webhook can both arrive; access is granted exactly once.
- Order and payment endpoints are rate-limited per IP; `/admin` uses Basic auth and refuses cross-site posts;
  CSV export is protected against spreadsheet formula injection.

---

## 5. Giving buyers access in the app

**Option A: automatic (recommended).** Set `ACCESS_WEBHOOK_URL` to an endpoint on your app backend and
`ACCESS_WEBHOOK_SECRET` to a shared secret. For every paid order this server POSTs:

```json
{
  "event": "purchase.completed",
  "idempotency_key": "P1-261030-9F3A1C2B",
  "product": "ugc-net-paper-1-test-series",
  "order": { "receipt": "P1-261030-9F3A1C2B", "plan_id": "p1-12m", "plan_name": "12 months", "months": 12,
             "amount_paise": 39900, "currency": "INR", "paid_at": "…", "valid_until": "…",
             "razorpay_order_id": "order_…", "razorpay_payment_id": "pay_…" },
  "customer": { "name": "…", "email": "…", "phone": "+919876543210" }
}
```

with header `X-Agni-Signature: hex(HMAC-SHA256(raw body, ACCESS_WEBHOOK_SECRET))`. Your backend should
check the signature, unlock the test series for that phone number until `valid_until`, and return any 2xx.
Use `idempotency_key` so a repeat call doesn't add time twice. Failed calls retry 3 times, then show as
**failed** in `/admin` with a **Retry access** button.

```js
// Verifying it on your backend (Express)
app.post('/internal/web-purchase', express.raw({ type: '*/*' }), (req, res) => {
  const expected = crypto.createHmac('sha256', process.env.ACCESS_WEBHOOK_SECRET).update(req.body).digest('hex');
  if (expected !== req.get('X-Agni-Signature')) return res.sendStatus(401);
  const p = JSON.parse(req.body);
  // unlock p.product for p.customer.phone until p.order.valid_until (skip if p.idempotency_key already done)
  res.sendStatus(200);
});
```

**Option B: manual.** Leave `ACCESS_WEBHOOK_URL` empty. Paid orders show as **manual** in `/admin`; activate
the buyer in your app, then click **Mark activated**. Fine for launch week, not for scale: the policies promise
activation within 24 hours.

---

## 6. Deploying

SQLite needs a **persistent disk**: your orders live in `DATABASE_FILE`. Back it up.

**VPS (DigitalOcean, Hostinger VPS, AWS Lightsail, etc.)**
```bash
git clone … && cd ugc-net-paper1 && npm ci --omit=dev
cp .env.example .env && nano .env
npm i -g pm2 && pm2 start server.js --name ugc-p1 && pm2 save && pm2 startup
```
Put Nginx in front (`proxy_pass http://127.0.0.1:3000;`) with HTTPS from Certbot. Keep `TRUST_PROXY=1`.

**Render / Railway**: create a Node web service (`npm ci`, `npm start`), add the `.env` values as environment
variables, and attach a persistent disk/volume (for example at `/var/data`, with `DATABASE_FILE=/var/data/orders.db`).

Health check: `GET /healthz`.

---

## 7. Project map

```
server.js              app setup, security headers, routes
config/site.js         prices, plans, product counts, company details, analytics IDs
config/content.js      units, features, free questions, FAQ
lib/razorpay.js        SDK client + signature checks
lib/fulfilment.js      the one place an order becomes "paid"
lib/access.js          tells your app backend to unlock the buyer
lib/db.js              SQLite schema and queries (+ daily clean-up of old unpaid checkouts)
lib/validate.js        name / email / Indian mobile checks
routes/api.js          /api/orders, /api/payments/verify, status polling
routes/webhook.js      /webhooks/razorpay
routes/admin.js        /admin, CSV export, retry / mark activated
routes/pages.js        landing page, receipt, policy pages
views/                 EJS templates (index, success, policies, admin)
public/                CSS, browser JS, favicon
test/e2e.test.js       end-to-end checks against a fake Razorpay
```

## 8. Useful Razorpay docs
- Node.js integration: https://razorpay.com/docs/payments/server-integration/nodejs/integration-steps/
- Webhook validation: https://razorpay.com/docs/webhooks/validate-test/
- Business website details (activation): https://razorpay.com/docs/payments/dashboard/account-settings/business-website-details/
