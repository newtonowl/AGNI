// End-to-end test against a fake Razorpay API. No real keys or network needed.
// Run: npm test
const assert = require('assert/strict');
const crypto = require('crypto');
const http = require('http');
const os = require('os');
const path = require('path');
const express = require('express');

const KEY_SECRET = 'test_secret_123';
const WEBHOOK_SECRET = 'whsec_test_456';
const ACCESS_SECRET = 'access_secret_789';
const sign = (data, secret) => crypto.createHmac('sha256', secret).update(data).digest('hex');

let passed = 0;
const ok = (name) => { passed++; console.log(`  ✓ ${name}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------- fake Razorpay + fake app backend
const orders = new Map();
const payments = new Map();
const accessCalls = [];
const fake = express();
// The app backend route reads the raw body to check the signature, so it goes before express.json().
fake.post('/app/access', express.text({ type: '*/*' }), (req, res) => {
  accessCalls.push({ body: req.body, sig: req.get('x-agni-signature') });
  res.json({ ok: true });
});
fake.use(express.json());
fake.post('/v1/orders', (req, res) => {
  assert.ok(req.headers.authorization.startsWith('Basic '), 'SDK must send basic auth');
  const id = `order_${crypto.randomBytes(7).toString('hex')}`;
  const o = { id, entity: 'order', amount: req.body.amount, currency: req.body.currency, receipt: req.body.receipt, notes: req.body.notes, status: 'created' };
  orders.set(id, o);
  res.json(o);
});
fake.get('/v1/payments/:id', (req, res) => {
  const p = payments.get(req.params.id);
  if (!p) return res.status(400).json({ error: { description: 'The id provided does not exist' } });
  res.json(p);
});
fake.post('/v1/payments/:id/capture', (req, res) => {
  const p = payments.get(req.params.id);
  if (p.status === 'captured') return res.status(400).json({ error: { description: 'This payment has already been captured' } });
  assert.equal(Number(req.body.amount), p.amount, 'capture amount must equal payment amount');
  p.status = 'captured';
  res.json(p);
});

(async () => {
  const fakeServer = http.createServer(fake).listen(0);
  await new Promise((r) => fakeServer.once('listening', r));
  const fakeUrl = `http://127.0.0.1:${fakeServer.address().port}`;

  Object.assign(process.env, {
    RAZORPAY_KEY_ID: 'rzp_test_dummy',
    RAZORPAY_KEY_SECRET: KEY_SECRET,
    RAZORPAY_WEBHOOK_SECRET: WEBHOOK_SECRET,
    ADMIN_USER: 'admin',
    ADMIN_PASSWORD: 'correct-horse-battery',
    ACCESS_WEBHOOK_URL: `${fakeUrl}/app/access`,
    ACCESS_WEBHOOK_SECRET: ACCESS_SECRET,
    DATABASE_FILE: path.join(os.tmpdir(), `ugc-p1-test-${Date.now()}.db`),
  });

  const app = require('../server');
  require('../lib/razorpay').client.api.rq.defaults.baseURL = fakeUrl; // point the SDK at the fake
  const { q } = require('../lib/db');
  const server = http.createServer(app).listen(0);
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}`;

  const post = (p, body, headers = {}) => fetch(base + p, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body) });
  const buyer = { planId: 'p1-12m', name: 'Asha Verma', phone: '98765 43210', email: 'Asha@Example.com', agree: true, utm_source: 'instagram', utm_campaign: 'p1_launch' };

  try {
    console.log('Pages');
    let r = await fetch(base + '/');
    let html = await r.text();
    assert.equal(r.status, 200);
    assert.ok(html.includes('₹399') && html.includes('₹199'), 'prices from config on page');
    assert.ok(html.includes('data-buy="p1-12m"'), 'buy buttons');
    assert.ok(!/<%|%>/.test(html), 'no raw template tags');
    ok('landing page renders with both prices');
    for (const p of ['/terms', '/privacy', '/refund-policy', '/shipping-policy', '/contact', '/about']) {
      r = await fetch(base + p);
      assert.equal(r.status, 200, p);
    }
    ok('all six policy pages return 200');
    r = await fetch(base + '/nope');
    assert.equal(r.status, 404);
    ok('unknown URL returns 404 page');

    console.log('Create order');
    r = await post('/api/orders', { planId: 'p1-12m', name: 'A', phone: '12345', email: 'x', agree: false });
    let j = await r.json();
    assert.equal(r.status, 400);
    assert.deepEqual(Object.keys(j.fields).sort(), ['agree', 'email', 'name', 'phone']);
    ok('invalid form is rejected with field errors');
    r = await post('/api/orders', { ...buyer, planId: 'free-plan' });
    assert.equal(r.status, 400);
    ok('unknown plan id is rejected');

    r = await post('/api/orders', { ...buyer, amount: 1 }); // a tampered amount must be ignored
    const o1 = await r.json();
    assert.equal(r.status, 200);
    assert.equal(o1.amount, 39900, 'amount comes from config, not the browser');
    assert.equal(o1.prefill.contact, '+919876543210');
    assert.equal(o1.prefill.email, 'asha@example.com');
    assert.equal(orders.get(o1.orderId).amount, 39900);
    assert.match(orders.get(o1.orderId).receipt, /^P1-\d{6}-[0-9A-F]{8}$/);
    ok('order created at ₹399 even when the browser sends amount: 1');

    console.log('Verify payment');
    const pay1 = `pay_${crypto.randomBytes(7).toString('hex')}`;
    payments.set(pay1, { id: pay1, order_id: o1.orderId, amount: 39900, currency: 'INR', status: 'authorized' });
    r = await post('/api/payments/verify', { razorpay_order_id: o1.orderId, razorpay_payment_id: pay1, razorpay_signature: 'deadbeef' });
    assert.equal(r.status, 400);
    ok('forged signature is rejected');
    r = await post('/api/payments/verify', { razorpay_order_id: o1.orderId, razorpay_payment_id: pay1, razorpay_signature: sign(`${o1.orderId}|${pay1}`, 'wrong-secret') });
    assert.equal(r.status, 400);
    ok('signature made with the wrong secret is rejected');
    r = await post('/api/payments/verify', { razorpay_order_id: o1.orderId, razorpay_payment_id: pay1, razorpay_signature: sign(`${o1.orderId}|${pay1}`, KEY_SECRET) });
    j = await r.json();
    assert.equal(r.status, 200);
    assert.equal(j.state, 'paid');
    assert.equal(payments.get(pay1).status, 'captured', 'authorized payment gets captured');
    let row = q.byRzpOrder.get(o1.orderId);
    assert.equal(row.status, 'paid');
    assert.equal(row.paid_via, 'checkout');
    assert.equal(row.utm_source, 'instagram');
    const months = Math.round((new Date(row.valid_until) - new Date(row.paid_at)) / (30.44 * 864e5));
    assert.equal(months, 12);
    ok('valid signature → payment captured, order paid, valid for 12 months');

    await sleep(300);
    assert.equal(accessCalls.length, 1, 'app backend called once');
    const call = accessCalls[0];
    assert.equal(call.sig, sign(call.body, ACCESS_SECRET), 'access call is signed');
    assert.equal(JSON.parse(call.body).customer.phone, '+919876543210');
    assert.equal(q.byRzpOrder.get(o1.orderId).access_status, 'granted');
    ok('app backend receives one signed purchase.completed call → access granted');

    r = await fetch(base + j.redirect);
    html = await r.text();
    assert.equal(r.status, 200);
    assert.ok(html.includes('Payment successful') && html.includes(pay1) && html.includes('₹399'));
    ok('success page shows the receipt');

    console.log('Webhook');
    r = await post('/api/orders', { ...buyer, planId: 'p1-3m', phone: '+91 91234 56789' });
    const o2 = await r.json();
    const pay2 = `pay_${crypto.randomBytes(7).toString('hex')}`;
    const pEntity = { id: pay2, entity: 'payment', order_id: o2.orderId, amount: 19900, currency: 'INR', status: 'captured' };
    payments.set(pay2, pEntity);
    const event = JSON.stringify({ entity: 'event', event: 'order.paid', created_at: 1793000000, payload: { payment: { entity: pEntity }, order: { entity: { id: o2.orderId, status: 'paid' } } } });
    r = await post('/webhooks/razorpay', event, { 'X-Razorpay-Signature': sign(event, 'nope'), 'X-Razorpay-Event-Id': 'evt_1' });
    assert.equal(r.status, 400);
    assert.equal(q.byRzpOrder.get(o2.orderId).status, 'created');
    ok('webhook with a bad signature is rejected and changes nothing');
    r = await post('/webhooks/razorpay', event, { 'X-Razorpay-Signature': sign(event, WEBHOOK_SECRET), 'X-Razorpay-Event-Id': 'evt_1' });
    assert.equal(r.status, 200);
    row = q.byRzpOrder.get(o2.orderId);
    assert.equal(row.status, 'paid');
    assert.equal(row.paid_via, 'webhook');
    ok('signed order.paid webhook marks the order paid (buyer closed the tab)');
    r = await post('/webhooks/razorpay', event, { 'X-Razorpay-Signature': sign(event, WEBHOOK_SECRET), 'X-Razorpay-Event-Id': 'evt_1' });
    assert.equal(await r.text(), 'duplicate');
    ok('repeated webhook delivery is ignored');
    // The checkout handler arriving after the webhook must not activate twice.
    r = await post('/api/payments/verify', { razorpay_order_id: o2.orderId, razorpay_payment_id: pay2, razorpay_signature: sign(`${o2.orderId}|${pay2}`, KEY_SECRET) });
    assert.equal((await r.json()).state, 'paid');
    await sleep(300);
    assert.equal(accessCalls.length, 2, 'one access call per order, not per confirmation');
    ok('webhook + checkout confirmation together grant access exactly once');

    console.log('Mismatch and pending');
    r = await post('/api/orders', buyer);
    const o3 = await r.json();
    const pay3 = `pay_${crypto.randomBytes(7).toString('hex')}`;
    payments.set(pay3, { id: pay3, order_id: o3.orderId, amount: 100, currency: 'INR', status: 'captured' });
    r = await post('/api/payments/verify', { razorpay_order_id: o3.orderId, razorpay_payment_id: pay3, razorpay_signature: sign(`${o3.orderId}|${pay3}`, KEY_SECRET) });
    assert.equal(r.status, 400);
    assert.equal(q.byRzpOrder.get(o3.orderId).status, 'created');
    ok('payment for the wrong amount does not unlock the order');

    r = await post('/api/orders', buyer);
    const o4 = await r.json();
    const pay4 = `pay_${crypto.randomBytes(7).toString('hex')}`;
    payments.set(pay4, { id: pay4, order_id: o4.orderId, amount: 39900, currency: 'INR', status: 'failed' });
    r = await post('/api/payments/verify', { razorpay_order_id: o4.orderId, razorpay_payment_id: pay4, razorpay_signature: sign(`${o4.orderId}|${pay4}`, KEY_SECRET) });
    j = await r.json();
    assert.equal(j.state, 'pending');
    html = await (await fetch(base + j.redirect)).text();
    assert.ok(html.includes('Confirming your payment'));
    r = await fetch(`${base}/api/orders/${o4.token}/status`);
    assert.equal((await r.json()).status, 'created');
    ok('unconfirmed payment shows the waiting page, which polls for status');

    console.log('Admin');
    r = await fetch(base + '/admin');
    assert.equal(r.status, 401);
    ok('admin needs a password');
    const auth = { Authorization: 'Basic ' + Buffer.from('admin:correct-horse-battery').toString('base64') };
    r = await fetch(base + '/admin', { headers: auth });
    html = await r.text();
    assert.equal(r.status, 200);
    assert.ok(html.includes(row.receipt) && html.includes('₹598'), 'lists orders and totals (399 + 199)');
    ok('admin lists orders with all-time sales of ₹598');
    r = await fetch(base + '/admin/orders.csv', { headers: auth });
    const csv = await r.text();
    assert.equal(csv.trim().split('\n').length, 5, 'header + 4 orders');
    ok('CSV export has every order');
    r = await fetch(`${base}/admin/orders/1/mark-activated`, { method: 'POST', headers: { ...auth, Origin: 'https://evil.example' } });
    assert.equal(r.status, 403);
    ok('cross-site admin POST is refused');

    console.log(`\nAll ${passed} checks passed.`);
  } catch (err) {
    console.error('\nFAILED:', err);
    process.exitCode = 1;
  } finally {
    server.close();
    fakeServer.close();
    setTimeout(() => process.exit(process.exitCode || 0), 100);
  }
})();
