const express = require('express');
const content = require('../config/content');
const { q } = require('../lib/db');

const router = express.Router();

const POLICIES = {
  terms: { view: 'policies/terms', title: 'Terms and Conditions' },
  privacy: { view: 'policies/privacy', title: 'Privacy Policy' },
  'refund-policy': { view: 'policies/refund', title: 'Cancellation and Refund Policy' },
  'shipping-policy': { view: 'policies/shipping', title: 'Shipping and Delivery Policy' },
  contact: { view: 'policies/contact', title: 'Contact Us' },
  about: { view: 'policies/about', title: 'About Us' },
};

router.get('/', (req, res) => {
  res.render('index', { page: 'home', content });
});

router.get('/success', (req, res) => {
  const order = req.query.t ? q.byToken.get(String(req.query.t)) : null;
  res.set('Cache-Control', 'no-store');
  res.set('X-Robots-Tag', 'noindex');
  if (!order) return res.status(404).render('404', { page: '404' });
  res.render('success', { page: 'success', order });
});

for (const [slug, p] of Object.entries(POLICIES)) {
  router.get(`/${slug}`, (req, res) => res.render(p.view, { page: slug, title: p.title, slug }));
}

module.exports = { router, POLICIES };
