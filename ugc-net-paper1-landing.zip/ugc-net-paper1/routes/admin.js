// /admin: password-protected list of orders, CSV export and access controls.
const crypto = require('crypto');
const express = require('express');
const { q, now } = require('../lib/db');
const { grantAccess } = require('../lib/access');

const router = express.Router();
const USER = process.env.ADMIN_USER || 'admin';
const PASS = process.env.ADMIN_PASSWORD || '';

function same(a, b) {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
}

router.use((req, res, next) => {
  if (!PASS || PASS.length < 10) {
    return res.status(503).send('Admin is disabled. Set ADMIN_PASSWORD (10+ characters) in .env to turn it on.');
  }
  const [type, value] = (req.get('authorization') || '').split(' ');
  if (type === 'Basic' && value) {
    const [u, ...rest] = Buffer.from(value, 'base64').toString('utf8').split(':');
    if (same(u, USER) & same(rest.join(':'), PASS)) {
      res.set('Cache-Control', 'no-store');
      res.set('X-Robots-Tag', 'noindex');
      return next();
    }
  }
  res.set('WWW-Authenticate', 'Basic realm="Agni Shiksha admin", charset="UTF-8"');
  return res.status(401).send('Login required');
});

// Basic auth is sent automatically by the browser, so refuse cross-site form posts.
function sameOrigin(req, res, next) {
  const origin = req.get('origin') || req.get('referer') || '';
  try {
    if (new URL(origin).host === req.get('host')) return next();
  } catch { /* fall through */ }
  return res.status(403).send('Cross-site request refused');
}

router.get('/', (req, res) => {
  const status = ['created', 'paid'].includes(req.query.status) ? req.query.status : '';
  const search = String(req.query.q || '').trim().slice(0, 80);
  const orders = q.list.all({ status, q: search, like: `%${search}%`, limit: 500 });
  const today = new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10); // IST date
  const startOfTodayIst = new Date(`${today}T00:00:00+05:30`).toISOString();
  res.render('admin', {
    orders,
    status,
    search,
    totals: q.totals.get(),
    todayTotals: q.totalsSince.get(startOfTodayIst),
    counts: Object.fromEntries(q.counts.all().map((r) => [r.status, r.n])),
    accessConfigured: Boolean(process.env.ACCESS_WEBHOOK_URL),
  });
});

router.get('/orders.csv', (req, res) => {
  const rows = q.list.all({ status: '', q: '', like: '%%', limit: 1000000 });
  const cols = ['receipt', 'status', 'access_status', 'plan_name', 'amount_paise', 'name', 'email', 'phone', 'rzp_order_id',
    'rzp_payment_id', 'created_at', 'paid_at', 'valid_until', 'paid_via', 'utm_source', 'utm_medium', 'utm_campaign', 'last_error'];
  const esc = (v) => {
    let s = v == null ? '' : String(v);
    if (/^[=+\-@]/.test(s)) s = `'${s}`; // stop spreadsheet formula injection
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = [cols.join(',')].concat(rows.map((r) => cols.map((c) => esc(r[c])).join(','))).join('\n');
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="ugc-net-p1-orders-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send('﻿' + csv);
});

router.post('/orders/:id/retry-access', sameOrigin, async (req, res) => {
  const order = q.byId.get(Number(req.params.id));
  if (order && order.status === 'paid') await grantAccess(order.id);
  res.redirect('/admin');
});

router.post('/orders/:id/mark-activated', sameOrigin, (req, res) => {
  const order = q.byId.get(Number(req.params.id));
  if (order && order.status === 'paid') q.setAccess.run('granted', 'Activated by hand from /admin', now(), order.id);
  res.redirect('/admin');
});

module.exports = router;
