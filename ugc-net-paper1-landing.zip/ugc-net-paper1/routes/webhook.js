// Razorpay webhook: the safety net for buyers who pay and then close the tab
// before our page hears back. Subscribe to: payment.authorized, payment.captured,
// payment.failed, order.paid. URL: https://YOUR-DOMAIN/webhooks/razorpay
const express = require('express');
const { db, q, now } = require('../lib/db');
const rzp = require('../lib/razorpay');
const { confirmPayment } = require('../lib/fulfilment');

const router = express.Router();

// express.raw keeps the exact bytes Razorpay signed. Do not swap this for express.json().
router.post('/razorpay', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
  const signature = req.get('x-razorpay-signature') || '';
  const raw = Buffer.isBuffer(req.body) ? req.body : Buffer.from('');

  if (!rzp.verifyWebhookSignature(raw, signature)) {
    console.warn('[webhook] rejected: bad signature');
    return res.status(400).send('invalid signature');
  }

  let body;
  try {
    body = JSON.parse(raw.toString('utf8'));
  } catch {
    return res.status(400).send('invalid json');
  }

  // Razorpay may deliver the same event more than once; process each id once.
  const eventId = req.get('x-razorpay-event-id') || `${body.event}:${body.created_at}:${body.payload?.payment?.entity?.id || ''}`;
  if (q.insertEvent.run(eventId, body.event || 'unknown', now()).changes === 0) {
    return res.status(200).send('duplicate');
  }

  try {
    const payment = body.payload?.payment?.entity;
    switch (body.event) {
      case 'payment.authorized':
      case 'payment.captured':
      case 'order.paid':
        if (payment?.order_id) {
          const result = await confirmPayment(payment.order_id, payment.id, 'webhook', payment);
          if (result.state === 'unknown') console.log(`[webhook] ${body.event} for an order this site did not create (${payment.order_id})`);
        }
        break;
      case 'payment.failed':
        if (payment?.order_id) {
          const reason = payment.error_description || payment.error_reason || 'Payment failed';
          q.setError.run(String(reason).slice(0, 300), now(), payment.order_id);
        }
        break;
      default:
        break;
    }
  } catch (err) {
    console.error('[webhook] processing error:', rzp.describeError(err));
    // Let Razorpay retry later: forget the event id so the retry is not treated as a duplicate.
    db.prepare('DELETE FROM webhook_events WHERE event_id = ?').run(eventId);
    return res.status(500).send('retry');
  }

  res.status(200).send('ok');
});

module.exports = router;
