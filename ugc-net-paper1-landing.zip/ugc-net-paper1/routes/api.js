const crypto = require('crypto');
const express = require('express');
const site = require('../config/site');
const { q, now } = require('../lib/db');
const rzp = require('../lib/razorpay');
const { confirmPayment } = require('../lib/fulfilment');
const { cleanName, cleanEmail, cleanPhone, cleanUtm } = require('../lib/validate');
const { rateLimit } = require('../lib/rate-limit');

const router = express.Router();
router.use(express.json({ limit: '10kb' }));

const plansById = Object.fromEntries(site.plans.map((p) => [p.id, p]));

function newReceipt() {
  const d = new Date();
  const ymd = d.toISOString().slice(2, 10).replace(/-/g, '');
  return `P1-${ymd}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`; // e.g. P1-261030-9F3A1C2B
}

// 1. Browser asks for an order. The price comes from config, never from the browser.
router.post('/orders', rateLimit({ windowMs: 10 * 60 * 1000, max: 15 }), async (req, res) => {
  const b = req.body || {};
  const plan = plansById[b.planId];
  const name = cleanName(b.name);
  const email = cleanEmail(b.email);
  const phone = cleanPhone(b.phone);

  const errors = {};
  if (!plan) errors.planId = 'Choose a plan.';
  if (!name) errors.name = 'Enter your full name.';
  if (!email) errors.email = 'Enter a valid email address.';
  if (!phone) errors.phone = 'Enter a valid 10-digit Indian mobile number.';
  if (b.agree !== true) errors.agree = 'Please accept the Terms and Refund Policy.';
  if (Object.keys(errors).length) return res.status(400).json({ error: 'Please check the highlighted fields.', fields: errors });

  const amountPaise = Math.round(plan.price * 100);
  const receipt = newReceipt();
  const token = crypto.randomBytes(18).toString('base64url');

  let order;
  try {
    order = await rzp.createOrder({
      amountPaise,
      currency: site.currency,
      receipt,
      notes: { product: site.product.name, plan: plan.id, phone, email },
    });
  } catch (err) {
    console.error('[orders] Razorpay order create failed:', rzp.describeError(err));
    return res.status(502).json({ error: 'We could not start the payment. Please try again in a minute.' });
  }

  q.insertOrder.run({
    token,
    receipt,
    plan_id: plan.id,
    plan_name: plan.name,
    months: plan.months,
    amount_paise: amountPaise,
    currency: site.currency,
    name,
    email,
    phone,
    rzp_order_id: order.id,
    utm_source: cleanUtm(b.utm_source),
    utm_medium: cleanUtm(b.utm_medium),
    utm_campaign: cleanUtm(b.utm_campaign),
    ip: req.ip,
    created_at: now(),
  });

  res.json({
    keyId: rzp.keyId,
    orderId: order.id,
    amount: amountPaise,
    currency: site.currency,
    token,
    brand: site.brand.name,
    description: `${site.product.name} · ${plan.name}`,
    prefill: { name, email, contact: phone },
    notes: { receipt },
    themeColor: site.brand.themeColor,
  });
});

// 2. Razorpay Checkout calls our page's handler; the page posts the three fields here.
router.post('/payments/verify', rateLimit({ windowMs: 10 * 60 * 1000, max: 40 }), async (req, res) => {
  const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature } = req.body || {};
  if (!orderId || !paymentId || !signature) return res.status(400).json({ error: 'Missing payment details.' });

  const order = q.byRzpOrder.get(String(orderId));
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  if (!rzp.verifyPaymentSignature(order.rzp_order_id, String(paymentId), String(signature))) {
    q.setError.run('Signature check failed', now(), order.rzp_order_id);
    return res.status(400).json({ error: 'We could not verify this payment. If money was deducted, contact support with your payment ID.' });
  }

  try {
    const result = await confirmPayment(order.rzp_order_id, String(paymentId), 'checkout');
    if (result.state === 'mismatch') return res.status(400).json({ error: 'Payment details did not match this order. Please contact support.' });
    // 'paid' or 'pending' both go to the success page; it waits for the webhook if needed.
    return res.json({ ok: true, state: result.state, redirect: `/success?t=${encodeURIComponent(order.token)}` });
  } catch (err) {
    console.error('[verify]', rzp.describeError(err));
    // Signature was valid, so the payment is real. Let the webhook finish the job.
    return res.json({ ok: true, state: 'pending', redirect: `/success?t=${encodeURIComponent(order.token)}` });
  }
});

// 3. Optional: the page reports a failed attempt so it shows up in /admin.
router.post('/payments/failed', async (req, res) => {
  const { orderId, reason } = req.body || {};
  if (orderId) q.setError.run(String(reason || 'Payment failed').slice(0, 300), now(), String(orderId));
  res.json({ ok: true });
});

// 4. The success page polls this while it waits for confirmation.
router.get('/orders/:token/status', (req, res) => {
  const order = q.byToken.get(req.params.token);
  if (!order) return res.status(404).json({ error: 'Not found' });
  res.json({ status: order.status });
});

module.exports = router;
