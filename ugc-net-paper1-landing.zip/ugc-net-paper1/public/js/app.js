/* UGC NET Paper 1 landing page: free quiz, checkout and Razorpay. No framework. */
(function () {
  'use strict';

  // ---------------------------------------------------------------- helpers
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function track(name, params) {
    try { if (window.gtag) window.gtag('event', name, params || {}); } catch (e) { /* ignore */ }
    try { if (window.fbq) window.fbq('track', name === 'begin_checkout' ? 'InitiateCheckout' : name, params || {}); } catch (e) { /* ignore */ }
  }
  var store = {
    get: function (k) { try { return window.sessionStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.sessionStorage.setItem(k, v); } catch (e) { /* private mode */ } },
  };
  var rupee = function (n) { return '₹' + Number(n).toLocaleString('en-IN'); };

  // Remember UTM tags from the ad or post that brought the visitor here.
  var params = new URLSearchParams(location.search);
  ['utm_source', 'utm_medium', 'utm_campaign'].forEach(function (k) {
    if (params.get(k)) store.set(k, params.get(k).slice(0, 100));
  });

  // ---------------------------------------------------------------- free quiz
  var quizData = $('#quizData');
  if (quizData) {
    var Q = JSON.parse(quizData.textContent);
    var i = 0, score = 0;
    var elQ = $('#quizQ'), elOpts = $('#quizOpts'), elWhy = $('#quizWhy'), elNext = $('#quizNext');
    var elStep = $('#quizStep'), elUnit = $('#quizUnit'), elBar = $('#quizBar'), elScore = $('#quizScore');

    var render = function () {
      var item = Q[i];
      elStep.textContent = 'Question ' + (i + 1) + ' of ' + Q.length;
      elUnit.textContent = item.unit;
      elQ.textContent = item.q;
      elBar.style.width = (i / Q.length * 100) + '%';
      elWhy.hidden = true;
      elNext.hidden = true;
      elOpts.innerHTML = '';
      item.options.forEach(function (text, k) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'opt';
        b.innerHTML = '<span class="opt__k">' + 'ABCD'[k] + '</span><span></span>';
        b.lastChild.textContent = text;
        b.addEventListener('click', function () { answer(k); });
        elOpts.appendChild(b);
      });
    };

    var answer = function (k) {
      var item = Q[i];
      var right = k === item.answer;
      if (right) score++;
      $$('.opt', elOpts).forEach(function (b, n) {
        b.disabled = true;
        if (n === item.answer) b.classList.add('is-right');
        if (n === k && !right) b.classList.add('is-wrong');
      });
      elWhy.innerHTML = '<b>' + (right ? 'Correct! +2 marks.' : 'Not quite. The answer is ' + 'ABCD'[item.answer] + '.') + '</b> ';
      elWhy.appendChild(document.createTextNode(item.why));
      elWhy.className = 'quiz__why ' + (right ? 'is-right' : 'is-wrong');
      elWhy.hidden = false;
      elNext.textContent = i < Q.length - 1 ? 'Next question' : 'See my score';
      elNext.hidden = false;
      elNext.focus({ preventScroll: true });
    };

    elNext.addEventListener('click', function () {
      i++;
      if (i < Q.length) return render();
      elBar.style.width = '100%';
      elStep.textContent = 'Done!';
      elUnit.textContent = '';
      elQ.textContent = 'You scored ' + score * 2 + ' out of ' + Q.length * 2 + '.';
      elOpts.innerHTML = '';
      elWhy.hidden = false;
      elWhy.className = 'quiz__why';
      elWhy.textContent = score === Q.length
        ? 'Perfect score. Now try it across 50 questions and a timer in a full-length mock.'
        : 'The full test series has a solution like these for every question, so each mistake becomes a mark next time.';
      elScore.textContent = '';
      elNext.textContent = 'Get the full test series';
      elNext.onclick = function () { openCheckout(); };
      track('quiz_complete', { score: score });
    });

    render();
  }

  // ---------------------------------------------------------------- sticky buy bar (mobile)
  var bar = $('#buybar'), pricing = $('#pricing'), hero = $('.hero');
  if (bar && 'IntersectionObserver' in window) {
    var heroGone = false, pricingVisible = false;
    var update = function () {
      var show = heroGone && !pricingVisible;
      bar.classList.toggle('is-on', show);
      bar.setAttribute('aria-hidden', show ? 'false' : 'true');
      bar.querySelector('button').tabIndex = show ? 0 : -1;
    };
    new IntersectionObserver(function (e) { heroGone = !e[0].isIntersecting; update(); }).observe(hero);
    new IntersectionObserver(function (e) { pricingVisible = e[0].isIntersecting; update(); }).observe(pricing);
  }

  // ---------------------------------------------------------------- checkout
  var dlg = $('#checkout'), form = $('#coForm');
  if (!dlg || !form) return;
  var payBtn = $('#coPay'), msg = $('#coMsg'), amountEl = $('#coAmount');
  var busy = false;

  function el(n) { return form.elements.namedItem(n); } // not form.name: that is the form's own name attribute
  function selectedPlan() { return form.querySelector('input[name=planId]:checked'); }
  function syncAmount() { var p = selectedPlan(); if (p) amountEl.textContent = rupee(p.dataset.price); }
  $$('input[name=planId]', form).forEach(function (r) { r.addEventListener('change', syncAmount); });

  function openCheckout(planId) {
    if (planId) {
      var r = form.querySelector('input[name=planId][value="' + planId + '"]');
      if (r) r.checked = true;
    }
    syncAmount();
    showMsg('');
    if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open', '');
    setTimeout(function () { (el('name').value ? el('phone') : el('name')).focus(); }, 30);
    var p = selectedPlan();
    track('begin_checkout', { currency: 'INR', value: p ? Number(p.dataset.price) : undefined });
    loadRazorpay().catch(function () { /* shown again on pay */ });
  }
  function closeCheckout() { if (dlg.open) { if (dlg.close) dlg.close(); else dlg.removeAttribute('open'); } }

  $$('[data-buy]').forEach(function (b) {
    b.addEventListener('click', function () { openCheckout(b.getAttribute('data-buy')); });
  });
  $$('[data-close]', dlg).forEach(function (b) { b.addEventListener('click', closeCheckout); });
  dlg.addEventListener('click', function (e) { if (e.target === dlg && !busy) closeCheckout(); });

  function showMsg(text, kind) {
    msg.hidden = !text;
    msg.textContent = text || '';
    msg.className = 'checkout__msg' + (kind ? ' is-' + kind : '');
  }
  function setBusy(on, label) {
    busy = on;
    payBtn.disabled = on;
    payBtn.classList.toggle('is-busy', on);
    if (label) payBtn.dataset.label = label;
    payBtn.innerHTML = on ? '<span class="spin" aria-hidden="true"></span>' + (label || 'Please wait…') : 'Pay <span id="coAmount"></span> securely';
    amountEl = $('#coAmount');
    if (!on) syncAmount();
  }
  function fieldErrors(fields) {
    $$('[data-err]', form).forEach(function (x) { x.textContent = ''; });
    $$('.is-invalid', form).forEach(function (x) { x.classList.remove('is-invalid'); });
    Object.keys(fields || {}).forEach(function (k) {
      var errEl = form.querySelector('[data-err="' + k + '"]');
      if (errEl) errEl.textContent = fields[k];
      var input = el(k);
      if (input && input.classList) (input.closest('.input') || input).classList.add('is-invalid');
    });
  }

  form.addEventListener('input', function (e) {
    var n = e.target.name;
    var errEl = n && form.querySelector('[data-err="' + n + '"]');
    if (errEl) errEl.textContent = '';
    (e.target.closest('.input') || e.target).classList.remove('is-invalid');
  });

  function validate() {
    var f = {};
    var name = el('name').value.trim();
    var phone = el('phone').value.replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, '');
    var email = el('email').value.trim();
    if (name.length < 2) f.name = 'Enter your full name.';
    if (!/^[6-9]\d{9}$/.test(phone)) f.phone = 'Enter a valid 10-digit mobile number.';
    if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) f.email = 'Enter a valid email address.';
    if (!el('agree').checked) f.agree = 'Please accept the Terms and Refund Policy.';
    fieldErrors(f);
    return Object.keys(f).length ? null : { name: name, phone: phone, email: email };
  }

  var rzpPromise = null;
  function loadRazorpay() {
    if (window.Razorpay) return Promise.resolve();
    if (rzpPromise) return rzpPromise;
    rzpPromise = new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = 'https://checkout.razorpay.com/v1/checkout.js';
      s.async = true;
      s.onload = function () { resolve(); };
      s.onerror = function () { rzpPromise = null; reject(new Error('load')); };
      document.head.appendChild(s);
    });
    return rzpPromise;
  }

  function post(url, body) {
    return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j._status = r.status; return j; }); });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (busy) return;
    var data = validate();
    if (!data) return;
    var plan = selectedPlan();
    showMsg('');
    setBusy(true, 'Starting secure payment…');

    Promise.all([
      loadRazorpay().catch(function () { throw new Error('We could not load the payment window. Check your internet connection and try again.'); }),
      post('/api/orders', {
        planId: plan.value, name: data.name, phone: data.phone, email: data.email, agree: true,
        utm_source: store.get('utm_source'), utm_medium: store.get('utm_medium'), utm_campaign: store.get('utm_campaign'),
      }),
    ]).then(function (res) {
      var o = res[1];
      if (o._status !== 200) {
        fieldErrors(o.fields);
        throw new Error(o.error || 'Something went wrong. Please try again.');
      }
      var rzp = new window.Razorpay({
        key: o.keyId,
        amount: o.amount,
        currency: o.currency,
        name: o.brand,
        description: o.description,
        order_id: o.orderId,
        prefill: o.prefill,
        notes: o.notes,
        theme: { color: o.themeColor },
        modal: {
          confirm_close: true,
          ondismiss: function () { setBusy(false); showMsg('Payment was cancelled. You have not been charged. You can try again whenever you are ready.'); },
        },
        handler: function (resp) {
          setBusy(true, 'Confirming your payment…');
          post('/api/payments/verify', resp).then(function (v) {
            if (v.ok && v.redirect) { location.href = v.redirect; return; }
            setBusy(false);
            showMsg((v.error || 'We could not confirm the payment.') + ' Payment ID: ' + resp.razorpay_payment_id, 'error');
          }).catch(function () {
            // Network blip after a successful payment: the webhook will still confirm it.
            location.href = '/success?t=' + encodeURIComponent(o.token);
          });
        },
      });
      rzp.on('payment.failed', function (r) {
        var reason = (r && r.error && (r.error.description || r.error.reason)) || 'Payment failed';
        post('/api/payments/failed', { orderId: o.orderId, reason: reason }).catch(function () { /* ignore */ });
        showMsg(reason + '. No money was taken for this attempt; if your bank shows a debit it will be reversed. You can try again, or use another method.', 'error');
      });
      setBusy(true, 'Waiting for payment…');
      rzp.open();
    }).catch(function (err) {
      setBusy(false);
      showMsg(err.message, 'error');
    });
  });
})();
