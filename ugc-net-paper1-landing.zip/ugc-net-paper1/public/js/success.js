/* Success page: waits for confirmation if needed, and reports the purchase once to analytics. */
(function () {
  'use strict';
  var box = document.getElementById('receipt');
  if (!box) return;

  if (box.dataset.paid === '1') {
    var key = 'purchase_tracked_' + box.dataset.receipt;
    var done = false;
    try { done = window.localStorage.getItem(key) === '1'; } catch (e) { /* private mode */ }
    if (!done) {
      var value = Number(box.dataset.value);
      try { if (window.gtag) window.gtag('event', 'purchase', { transaction_id: box.dataset.receipt, value: value, currency: 'INR', items: [{ item_id: box.dataset.plan, item_name: 'UGC NET Paper 1 Test Series', price: value, quantity: 1 }] }); } catch (e) { /* ignore */ }
      try { if (window.fbq) window.fbq('track', 'Purchase', { value: value, currency: 'INR' }, { eventID: box.dataset.receipt }); } catch (e) { /* ignore */ }
      try { window.localStorage.setItem(key, '1'); } catch (e) { /* ignore */ }
    }
    return;
  }

  // Not confirmed yet: poll for up to about 5 minutes, then explain what happens next.
  var token = box.dataset.token, tries = 0, max = 100;
  var tick = function () {
    tries++;
    fetch('/api/orders/' + encodeURIComponent(token) + '/status', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.status === 'paid') return location.reload();
        if (tries < max) return setTimeout(tick, 3000);
        document.getElementById('waitTitle').textContent = 'Still waiting for your bank';
        document.getElementById('waitText').textContent = 'Some UPI and net banking payments take longer to confirm. You can close this page: once your bank confirms, your test series is activated on your mobile number. If the payment fails instead, the money is refunded to you automatically.';
      })
      .catch(function () { if (tries < max) setTimeout(tick, 5000); });
  };
  setTimeout(tick, 1500);
})();
