require('dotenv').config({ quiet: true });

const path = require('path');
const express = require('express');
const site = require('./config/site');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');

// Behind Nginx, Render, Railway or Cloudflare the real visitor IP is in X-Forwarded-For.
app.set('trust proxy', process.env.TRUST_PROXY === undefined ? 1 : Number(process.env.TRUST_PROXY));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.disable('x-powered-by');

app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.set('X-Frame-Options', 'SAMEORIGIN');
  if (BASE_URL.startsWith('https://')) res.set('Strict-Transport-Security', 'max-age=15552000');
  next();
});

// Shared template data and helpers.
const inr = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 });
app.locals.site = site;
app.locals.icon = require('./lib/icons').icon;
app.locals.baseUrl = BASE_URL;
app.locals.rupees = (n) => `₹${inr.format(n)}`;
app.locals.fromPaise = (p) => `₹${inr.format(p / 100)}`;
app.locals.istDate = (iso, withTime) =>
  iso
    ? new Date(iso).toLocaleString('en-IN', {
        timeZone: 'Asia/Kolkata',
        day: 'numeric', month: 'long', year: 'numeric',
        ...(withTime ? { hour: 'numeric', minute: '2-digit', hour12: true } : {}),
      }) + (withTime ? ' IST' : '')
    : '';
app.locals.phone = (p) => (/^\+91\d{10}$/.test(p || '') ? `+91 ${p.slice(3, 8)} ${p.slice(8)}` : p || '');
app.locals.cheapest = Math.min(...site.plans.map((p) => p.price));
app.locals.year = new Date().getFullYear();
// Cache-busting: pages ask for /css/style.css?v=<hash>, so a deploy never pairs new HTML with old CSS.
const fs = require('fs');
const crypto = require('crypto');
app.locals.v = crypto.createHash('md5')
  .update(fs.readFileSync(path.join(__dirname, 'public/css/style.css')))
  .update(fs.readFileSync(path.join(__dirname, 'public/js/app.js')))
  .digest('hex').slice(0, 10);

app.use(express.static(path.join(__dirname, 'public'), { maxAge: '7d', index: false }));

app.get('/healthz', (req, res) => res.json({ ok: true }));
app.use('/webhooks', require('./routes/webhook'));
app.use('/api', require('./routes/api'));
app.use('/admin', require('./routes/admin'));
app.use('/', require('./routes/pages').router);

app.use((req, res) => res.status(404).render('404', { page: '404' }));
app.use((err, req, res, next) => {
  console.error('[error]', err);
  if (req.path.startsWith('/api') || req.path.startsWith('/webhooks')) return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  res.status(500).send('Something went wrong. Please try again.');
});

if (require.main === module) {
  app.listen(PORT, () => {
    const mode = (process.env.RAZORPAY_KEY_ID || '').startsWith('rzp_live_') ? 'LIVE' : 'TEST';
    console.log(`UGC NET Paper 1 landing page on ${BASE_URL} (Razorpay ${mode} mode)`);
    if (!process.env.RAZORPAY_WEBHOOK_SECRET) console.warn('Warning: RAZORPAY_WEBHOOK_SECRET is not set, so webhooks will be rejected.');
  });
}

module.exports = app;
